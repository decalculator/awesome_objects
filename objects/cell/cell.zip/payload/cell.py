import asyncio
import random

from le_vent.modules.json.json import *
from le_vent.modules.path.path import *

from le_vent.plugins.representation.representation import *

async def cell(**kwargs):
    # {'variables': {'memory': <le_vent.modules.memory.memory.Memory object at 0x110faccd0>, 'pid_manager': <le_vent.modules.pid_manager.pid_manager.PidManager object at 0x110faca50>, 'usoi': 10000, 'pid': <le_vent.modules.dynamic_value.dynamic_value.DynamicValue object at 0x127bf8f50>, 'ppid': <le_vent.modules.dynamic_value.dynamic_value.DynamicValue object at 0x127bf8fd0>}}

    if "variables" in kwargs:
        variables = kwargs["variables"]

        memory = variables["memory"]
        pid_manager = variables["pid_manager"]
        usoi = variables["usoi"]
        pid = variables["pid"]
        ppid = variables["ppid"]

        path = Path(f"proc/instances/modules/{usoi}")
        if not memory.exists(path):
            memory.write(path, {})

        shared_memory_path = path / "shared_memory"

        if memory.exists(shared_memory_path):
            shared_memory = memory.get(shared_memory_path)

            shared_memory["position"][0] += 1
            shared_memory["position"][1] += 1

            memory.write(shared_memory_path, shared_memory)

        else:
            shared_memory = {"position": [random.randint(0, 100), random.randint(0, 100)], "animation": {"frames": ["core/objects/cell/frames/0.png", "core/objects/cell/frames/1.png", "core/objects/cell/frames/2.png"], "last": None}}
            memory.write(shared_memory_path, shared_memory)

        print(memory.get(Path("")))

        if await variables.exists(Path("representation/object")) and await variables.exists(Path("moment/object")) and await variables.exists(Path("objects")) and await variables.exists(Path(f"objects/{unique_object_id}")):
            moment_var = await variables.get(Path("moment/object"))
            moment = moment_var.value
            now = await moment.get(Path("time/value1"))

            memory = await variables.get(Path(f"objects/{unique_object_id}"))
            mem_data = memory.value

            representation_var = await variables.get(Path("representation/object"))
            representation = representation_var.value

            if "animation" in mem_data:
                animation = mem_data["animation"]
                if "frames" in animation and "last" in animation:
                    frames = animation["frames"]
                    last_frame = animation["last"]

                    if last_frame == None:
                        last_frame = 0
                    else:
                        if last_frame == len(frames) - 1:
                            last_frame = 0
                        else:
                            last_frame += 1

                    mem_data["animation"]["last"] = last_frame

                    await representation.write(Path(f"objects/{unique_object_id}"), {
                        "mode": "image",
                        "render": 2,
                        "path": frames[last_frame],
                        "position": [mem_data["position"][0], mem_data["position"][1]],
                        "refresh": True,
                        "done": False
                    })

    return 1